public class WorldMap {
    public static void main(String[] args) {
        int width = StdIn.readInt();
        int height = StdIn.readInt();

        StdDraw.setCanvasSize(width, height);
        StdDraw.setXscale(0, width);
        StdDraw.setYscale(0, height);

        while (!StdIn.isEmpty()) {
            String regionName = StdIn.readString();
            int n = StdIn.readInt();
            double[] x_coordinates = new double[n];
            double[] y_coordinates = new double[n];
            for (int i = 0; i < n; i++) {

                double x = StdIn.readDouble();
                double y = StdIn.readDouble();

                x_coordinates[i] = x;
                y_coordinates[i] = y;
            }
            StdDraw.polygon(x_coordinates, y_coordinates);
        }
    }
}
