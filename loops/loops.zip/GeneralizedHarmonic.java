public class GeneralizedHarmonic {
    public static void main(String[] args) {

        // compute the nth generalized harmonic number of order r


        int n = Integer.parseInt(args[0]), r = Integer.parseInt(args[1]);

        double result = 0.0;

        for (int i = 1; i <= n; i++) {
            result += (1 / Math.pow(i, r));
        }

        System.out.println(result);

    }
}
